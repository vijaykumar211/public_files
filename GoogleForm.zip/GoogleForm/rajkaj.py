import requests,re,time,random,os
from fake_useragent import UserAgent
from concurrent.futures import ThreadPoolExecutor
ua = UserAgent()


mobs = ["6350","6375","6376","6377","6378","7000","7005","7014","7023","7053","7062","7073","7208","7221","7229","7230","7231","7232","7240","7296","7297","7300","7339","7340","7357","7378","7398","7410","7413","7414","7415","7424","7427","7500","7507","7568","7597","7610","7611","7615","7619","7627","7665","7677","7678","7688","7689","7690","7691","7709","7725","7726","7727","7728","7732","7733","7737","7740","7742","7790","7791","7792","7793","7799","7839","7850","7877","7891","7976","7982","8003","8005","8006","8058","8074","8078","8094","8104","8107","8112","8114","8130","8178","8209","8233","8239","8278","8285","8287","8290","8302","8306","8318","8319","8320","8377","8380","8384","8385","8386","8387","8426","8427","8432","8440","8441","8447","8448","8476","8502","8503","8504","8505","8529","8559","8560","8561","8562","8588","8605","8619","8690","8696","8739","8740","8741","8742","8764","8766","8767","8769","8788","8823","8824","8829","8852","8854","8866","8875","8890","8919","8920","8946","8947","8949","8950","8952","8955","8963","8968","8982","8983","9001","9004","9015","9024","9027","9044","9057","9079","9099","9116","9119","9166","9212","9214","9219","9251","9252","9261","9269","9307","9309","9314","9351","9352","9395","9406","9408","9413","9414","9416","9423","9424","9460","9461","9462","9468","9509","9511","9521","9529","9530","9540","9549","9571","9575","9586","9587","9588","9589","9597","9602","9610","9619","9636","9643","9649","9651","9653","9654","9660","9664","9667","9672","9680","9694","9716","9717","9742","9752","9768","9772","9774","9782","9783","9784","9785","9795","9799","9811","9812","9818","9827","9828","9829","9871","9872","9873","9875","9882","9884","9887","9892","9917","9926","9928","9929","9950","9956","9958","9968","9971","9980","9982","9983","9986"]

distsss = ["Ajmer","Alwar","Barmer","Bharatpur","Bhilwara","Bikaner","Bundi","Chittorgarh","Churu","Jaipur","Jaipur","Jaipur","Jaipur","Jaipur","Jaipur","Jaipur","Jaipur","Jaipur","Jaipur","Kota","Sikar","Udaipur","Ajmer","Alwar","Banswara","Baran","Barmer","Bharatpur","Bhilwara","Bikaner","Bundi","Chittorgarh","Churu","Dausa","Dholpur","Dungarpur","Hanumangarh","Jaipur","Jaisalmer","Jalore","Jhalawar","Jhunjhunu","Jodhpur","Karauli","Kota","Nagaur","Pali","Pratapgarh","Rajsamand","Sawai Madhopur","Sikar","Sirohi","Sri Ganganagar","Tonk","Udaipur"]

headers22 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Language': 'en-IN,en;q=0.9,hi;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
}

#prxs = requests.get('http://3.16.21.52/proxy-scraperas/out1.txt', headers=headers22, verify=False).text.split("\n")

import csv

desgs = open("desg.txt","r").read().split("\n")

names = open("names.txt","r").read().split("\n")

def get_url(url):
	try:
		s = requests.Session()
		randd = (random.randint(2,10))
		#time.sleep(randd)
	
		desg  = (random.choice(desgs)).lower()
	
	
		dist = (random.choice(distsss)).lower()
		fullname = (random.choice(names)).lower().rsplit(' ', 1)
		#print(fullname)
		
		fname = fullname[0].rstrip(' ')
		lname = fullname[1].rstrip(' ')
		
		mob = str(random.choice(mobs))+str(random.randint(123212,987947))
		print(mob)
		
		email = [fname,lname,".",str(random.randint(1,99)),str(random.randint(99,999))]
		
		fnameg = random.choice([email[0].split(" ")[0],email[0].split(" ")[-1],email[0]])
		lnameg = random.choice([email[1].split(" ")[0],email[1].split(" ")[-1],email[1]])
		
		name = [fnameg,lnameg]
		random.shuffle(name)
		
		
		emailg = (name[0]+random.choice(["","."])+name[1]+random.choice(["","."])+random.choice(["",str(random.randint(9,999))])).rstrip('.')+"@"+random.choice(["gmail.com","gmail.com","gmail.com","gmail.com","gmail.com","gmail.com","gmail.com","gmail.com","gmail.com","gmail.com","yahoo.com","hotmail.com","live.com","yahoo.co.in"])
		emailg = (emailg.replace(" ","")).lower()
		print((emailg))
	
		deptnm = (random.choice(["DOIT","doitc","DoiT","DOIT&C","doit&c","DOP","Secretarait","Education","RVVN","CMO","IT","ITC","Rajkaj","DoIT&C","Transport","Treasury","Finance","ADA","JDA","UDA","UDH","LGS","Court","DES"]))
	
		headers = {
		    'authority': 'docs.google.com',
		    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
		    'accept-language': 'en-IN,en;q=0.9',
		    'cache-control': 'no-cache',
		    'pragma': 'no-cache',
		    'sec-ch-ua-mobile': '?0',
		    'sec-ch-ua-model': '""',
		    'sec-fetch-dest': 'document',
		    'sec-fetch-mode': 'navigate',
		    'sec-fetch-site': 'none',
		    'sec-fetch-user': '?1',
		    'upgrade-insecure-requests': '1',
		    'user-agent': ua.random,
		}
		
		params = {
		    'embedded': 'true',
		}
		
		response = s.get('https://docs.google.com/forms/d/e/1FAIpQLSc9h6eX0hYdI-JJTUP8ZtT5XEsRWDqGqWgF77MFJq3Nq99YEg/formResponse', params=params, headers=headers)
		#print(response.text)
		
		matsc = re.findall('ame="fbzx" value="(.*)"><input type="hidden"',response.text)
		matsc = (matsc[0])
		
		
		headers = {
		    'authority': 'docs.google.com',
		    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
		    'accept-language': 'en-IN,en;q=0.9',
		    'cache-control': 'no-cache',
		    'origin': 'https://docs.google.com',
		    'pragma': 'no-cache',
		    'referer': 'https://docs.google.com/forms/d/e/1FAIpQLSc9h6eX0hYdI-JJTUP8ZtT5XEsRWDqGqWgF77MFJq3Nq99YEg/viewform?embedded=true&fbzx='+str(matsc),
		    'sec-ch-ua-mobile': '?0',
		    'sec-ch-ua-model': '""',
		    'sec-fetch-dest': 'document',
		    'sec-fetch-mode': 'navigate',
		    'sec-fetch-site': 'same-origin',
		    'sec-fetch-user': '?1',
		    'upgrade-insecure-requests': '1',
		    'user-agent': ua.random,
		}
		
		params = {
		    'embedded': 'true',
		}
		
		data = {
		    'entry.82537205': fnameg,
		    'entry.699138706': lnameg,
		    'entry.1578616250': desg,
		    'entry.1423769822': emailg,
		    'entry.524309291': deptnm,
		    'entry.726699506': dist,
		    'entry.609066048': mob,
		    'entry.1058025205': 'Rajasthan',
		    'entry.18465063': 'RajKaj (Integrated Rajasthan e-Office Project)-Department of Information Technology & Communication (DoIT&C), Government of Rajasthan',
		    'entry.2122580329': 'I accept the terms & conditions',
		    'entry.1058025205_sentinel': '',
		    'entry.18465063_sentinel': '',
		    'entry.2122580329_sentinel': '',
		    'fvv': '1',
		    'partialResponse': '[null,null,"'+str(matsc)+'"]',
		    'pageHistory': '0',
		    'fbzx': str(matsc),
		    'dsdoc': 'true',
		}
		print(data)
		#exit()
		if len(emailg)>21:
			response = s.post('https://docs.google.com/forms/d/e/1FAIpQLSc9h6eX0hYdI-JJTUP8ZtT5XEsRWDqGqWgF77MFJq3Nq99YEg/formResponse', params=params, headers=headers, data=data)
	except:
		print("eeeerrrrrrooooooorrrrr")	
	
with ThreadPoolExecutor(max_workers=20) as pool:
    (list(pool.map(get_url,range(1,5000))))