import requests,time
from concurrent.futures import ThreadPoolExecutor


def get_url(url):
    print(url)
    time.sleep(1)
    
with ThreadPoolExecutor(max_workers=50) as pool:
    (list(pool.map(get_url,range(1,1000))))