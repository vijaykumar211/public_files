i=0
while i=1
	do
		python3 rajkaj.py;
		sleep 1s;
	done

