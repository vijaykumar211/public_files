jQuery(document).ready(function ($) {
    "use strict";
}); // end ready function